package com.example.guiaundertale

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Ruta(val nombre: String, val color: Color, val resumen: String, val inicio: List<String>, val pasos: List<String>)
data class Obj(val nombre: String, val tipo: String, val valor: Int, val nota: String)

val RUTAS = listOf(
    Ruta("Neutral", Color(0xFF9E9E9E), "Ni todos mueren ni todos se salvan. Es lo que casi todos obtienen en su primera partida.",
        listOf("No necesitas nada especial: solo juega y decide en cada combate.",
            "Para que no sea Pacifista, mata al menos a un monstruo.",
            "Para que no sea Genocida, deja con vida a algún monstruo de alguna zona."),
        listOf("Recorre Ruinas, Snowdin, Waterfall, Hotland y el Núcleo.",
            "Cada jefe puede perdonarse o matarse, y eso cambia el final.",
            "Llega al Nuevo Hogar y enfrenta a Asgore.",
            "Si mataste a alguien, habrá un juicio antes del final.")),
    Ruta("Pacifista", Color(0xFFFFE600), "Nadie muere por tu mano. Es el final verdadero y el más largo.",
        listOf("No mates a ningún monstruo: tu nivel (LV) debe quedar en 1.",
            "Usa Piedad en cada combate o huye cuando no puedas perdonar.",
            "No abandones la partida a medias: el final depende de todo el recorrido."),
        listOf("Con Toriel no ataques: perdona hasta que ella ceda.",
            "Haz amistad con Papyrus, Undyne y Alphys cuando el juego lo permita.",
            "Contesta las llamadas telefónicas: te indican qué hacer después.",
            "En Hotland, ayuda a Undyne cuando se desmaye por el calor.",
            "Perdona también a los jefes finales y sigue la historia hasta el final.")),
    Ruta("Genocida", Color(0xFFE53935), "Eliminas a todos los monstruos. Contenido violento: es la ruta más difícil.",
        listOf("Mata a todos los monstruos de cada zona, sin perdonar a nadie.",
            "Sigue hasta que el juego avise de que ya no quedan encuentros en esa zona.",
            "Hazlo zona por zona, en orden: Ruinas, Snowdin, Waterfall y Hotland."),
        listOf("Los jefes también deben morir, así que prepárate bien.",
            "Si perdonas a alguien o dejas encuentros pendientes, la ruta se arruina.",
            "Guarda partida seguido: un error obliga a repetir una zona.",
            "El final tiene combates muy duros; ten a mano objetos de curación.")))

val OBJ = listOf(
    Obj("Palo", "Arma", 0, "(Stick) inicial"), Obj("Cuaderno roto", "Arma", 2, "(Torn Notebook)"),
    Obj("Cuchillo de juguete", "Arma", 3, "(Toy Knife)"), Obj("Guante resistente", "Arma", 5, "(Tough Glove)"),
    Obj("Zapatillas de ballet", "Arma", 7, "(Ballet Shoes)"), Obj("Sartén quemada", "Arma", 10, "(Burnt Pan)"),
    Obj("Pistola vacía", "Arma", 12, "(Empty Gun)"), Obj("Daga gastada", "Arma", 15, "(Worn Dagger)"),
    Obj("Cuchillo real", "Arma", 99, "(Real Knife) ruta genocida"),
    Obj("Venda", "Armadura", 0, "(Bandage) inicial"), Obj("Listón desgastado", "Armadura", 3, "(Faded Ribbon)"),
    Obj("Gafas nubladas", "Armadura", 5, "(Cloudy Glasses)"), Obj("Pañuelo varonil", "Armadura", 7, "(Manly Bandanna)"),
    Obj("Tutú viejo", "Armadura", 10, "(Old Tutu)"), Obj("Delantal manchado", "Armadura", 11, "(Stained Apron)"),
    Obj("Armadura Temmie", "Armadura", 20, "(Temmie Armor)"))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFFFE600), background = Color(0xFF0A0A0A),
                surface = Color(0xFF161616), onSurface = Color(0xFFEEEEEE))) { App() }
        }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = {
        NavigationBar {
            NavigationBarItem(tab == 0, { tab = 0 }, { Text("🗺") }, label = { Text("Rutas") })
            NavigationBarItem(tab == 1, { tab = 1 }, { Text("⚔") }, label = { Text("Objetos") })
        }
    }) { pad ->
        Column(Modifier.padding(pad).statusBarsPadding().padding(horizontal = 16.dp)) {
            Text("Guía Undertale · Beta", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text("Guía no oficial de fans. Hecha de memoria: verifica en el juego.", fontSize = 11.sp, color = Color.Gray)
            Spacer(Modifier.height(8.dp))
            if (tab == 0) Rutas() else Objetos()
        }
    }
}

@Composable
fun Rutas() = LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    items(RUTAS) { r ->
        var open by remember { mutableStateOf(false) }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), onClick = { open = !open }) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Ruta ${r.nombre}", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = r.color)
                Text(r.resumen, fontSize = 14.sp)
                if (open) {
                    Text("Cómo iniciar", fontWeight = FontWeight.SemiBold, color = r.color)
                    r.inicio.forEach { Text("• $it", fontSize = 14.sp) }
                    Text("Cómo seguirla", fontWeight = FontWeight.SemiBold, color = r.color)
                    r.pasos.forEachIndexed { i, s -> Text("${i + 1}. $s", fontSize = 14.sp) }
                } else Text("Toca para ver los pasos", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun Objetos() {
    var q by remember { mutableStateOf("") }
    var f by remember { mutableStateOf("Todo") }
    val lista = OBJ.filter { (f == "Todo" || it.tipo == f) && (it.nombre.contains(q, true) || it.nota.contains(q, true)) }.sortedBy { it.valor }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("Buscar objeto") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Todo", "Arma", "Armadura").forEach { FilterChip(f == it, { f = it }, { Text(it) }) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(lista) { o ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(o.nombre, fontWeight = FontWeight.SemiBold)
                            Text("${o.tipo} ${o.nota}", fontSize = 12.sp, color = Color.Gray)
                        }
                        Text("${if (o.tipo == "Arma") "ATQ" else "DEF"} ${o.valor}", fontSize = 18.sp,
                            fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}
